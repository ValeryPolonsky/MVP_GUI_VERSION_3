package Model;

public class DataFromProperties {
	private String defaultAlgorithm;
	private String maxMazeSize;
	private String viewSetup;
	
	public DataFromProperties()
	{
		
	}
	
	public String getDefaultAlgorithm() {
		return defaultAlgorithm;
	}
	
	public void setDefaultAlgorithm(String defaultAlgorithm) {
		this.defaultAlgorithm = defaultAlgorithm;
	}

	public String getMaxMazeSize() {
		return maxMazeSize;
	}

	public void setMaxMazeSize(String maxMazeSize) {
		this.maxMazeSize = maxMazeSize;
	}

	public String getViewSetup() {
		return viewSetup;
	}

	public void setViewSetup(String viewSetup) {
		this.viewSetup = viewSetup;
	}
}
