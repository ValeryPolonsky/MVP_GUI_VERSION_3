package algorithms.search;

import org.junit.Assert;
import org.junit.Test;

import algorithms.mazeGenerators.Maze3DSearchable;


public class BFSTest {

	@Test
	public void test() {
		Maze3DSearchable searchable = new Maze3DSearchable(null);
		BFS searcher = new BFS();
		Assert.assertNull(searcher.Search(null));
		Assert.assertNull(searcher.Search(searchable));
	}
}
