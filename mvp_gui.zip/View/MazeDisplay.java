package View;


import java.util.Random;
import java.util.Stack;
import java.util.Timer;
import java.util.TimerTask;

import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Composite;

import algorithms.mazeGenerators.Maze3d;
import algorithms.mazeGenerators.Position;
import algorithms.search.Solution;
import algorithms.search.State;


public class MazeDisplay extends Canvas{

	
	int[][]mazeData={
			{0,0,0},
			{0,0,0},
			{0,0,0},
		};
	int[][][]mazeAs3DimArray;
	
	GameCharacter gameCharacter;
	Timer timer;
	TimerTask timerTask;
	Solution solution;
	boolean firstPath;
	Position previous;
	Position currentPosition=new Position(1,1,1);
	String perspective="";
	String level;
	Position exit;
	boolean gameStarted;
	boolean displayingSolution=false;
	

	
	public MazeDisplay(Composite parent,int style) {
		super(parent,style);
		level="1";
		gameCharacter=new GameCharacter(0,0,0);
		setBackground(new Color(null,255,255,255));
		currentPosition=new Position(0,1,1);
		gameStarted=false;
		exit=new Position();
		
		addPaintListener(new PaintListener(){

			@Override
			public void paintControl(PaintEvent e) {
				if(gameStarted)
				{
				e.gc.setForeground(new Color(null,0,0,0));
				e.gc.setBackground(new Color(null,0,0,0));
				
				int width=getSize().x;
				int height=getSize().y;
				
				int w=width/mazeData[0].length;
				int h=height/mazeData.length;
				
				for(int i=0;i<mazeData.length;i++)
				{
					for(int j=0;j<mazeData[i].length;j++)
					{
						int x=j*w;
						int y=i*h;
						if(mazeData[i][j]!=0)
						{
							e.gc.fillRectangle(x,y,w,h);
						}
					}
				}
				
					gameCharacter.paint(e, w, h);
			        gameCharacter.y=currentPosition.getX()*h;
				    gameCharacter.x=currentPosition.getZ()*w;
				}
				
				
			}
			
		});
	}
	
	public void startGame()
	{
		gameStarted=true;
	}
	
	public boolean ifGameStarted()
	{
		return gameStarted;
	}
	
	public void setMazeData(int[][]mazeData)
	{
		this.mazeData=mazeData;
		
		int width=getSize().x;
		int height=getSize().y;
		
		int w=width/mazeData[0].length;
		int h=height/mazeData.length;
	    
	    gameCharacter.y=currentPosition.getX()*h;
		gameCharacter.x=currentPosition.getZ()*w;
	    
		redraw();
	}
	
	public void setMaze(int[][][]mazeAs3dimArray)
	{
		this.mazeAs3DimArray=mazeAs3dimArray;
	}
	
	@SuppressWarnings("rawtypes")
	public void setSolution(Solution solution)
	{
		this.solution=solution;
		Stack<State>solutionPathes=solution.getSolution();
		/*int startPositionX=((new Position()).toPosition(solutionPathes.peek().getStateName().toString())).getX();
		int startPositionY=((new Position()).toPosition(solutionPathes.peek().getStateName().toString())).getZ();
		int startPositionZ=((new Position()).toPosition(solutionPathes.peek().getStateName().toString())).getY();
		currentPosition.setX(startPositionX);
		currentPosition.setY(startPositionY);
		currentPosition.setZ(startPositionZ);
		System.out.println(startPositionX);
		System.out.println(startPositionY);
		System.out.println(startPositionZ);*/
		
	}
	
	
	public boolean levelChanged(Position previous,Position current)
	{
		if(previous.getY()!=current.getY())
			return true;
		else
			return false;
	}
	
	public void setNewLevelData(Position position)
	{
		int y=position.getY();
		if(y>-1&&y<mazeAs3DimArray[0].length)
		{
			for(int x=0;x<mazeAs3DimArray.length;x++)
			{
				for(int z=0;z<mazeAs3DimArray[0][0].length;z++)
				{
					mazeData[x][z]=mazeAs3DimArray[x][y][z];
				}
			}
		}
	}
	
	@SuppressWarnings("rawtypes")
	public void start()
	{
		displayingSolution=true;
		Stack<State>solutionPathes=solution.getSolution();
		int startPositionX=((new Position()).toPosition(solutionPathes.peek().getStateName().toString())).getX();
		int startPositionY=((new Position()).toPosition(solutionPathes.peek().getStateName().toString())).getZ();
		previous=new Position();
		firstPath=true;
		timer=new Timer();
		timerTask=new TimerTask(){

			@Override
			public void run() {
				getDisplay().syncExec(new Runnable(){

					
					@Override
					public void run() {
						
						int width=getSize().x;
						int height=getSize().y;
						
						int w=width/mazeData[0].length+startPositionX/mazeData[0].length;
						int h=height/mazeData.length+startPositionY/mazeData.length;
						
						
						Position current=new Position();
						if(!solutionPathes.isEmpty())
						{
							if(!firstPath)
							{
								if(!levelChanged(previous,current))
								{
									previous=previous.toPosition(solutionPathes.peek().getStateName().toString());
									current=current.toPosition(solutionPathes.pop().getStateName().toString());
									gameCharacter.y=current.getX()*h;
									gameCharacter.x=current.getZ()*w;
								}
								else
								{
									previous=previous.toPosition(solutionPathes.peek().getStateName().toString());
									current=current.toPosition(solutionPathes.pop().getStateName().toString());
									setNewLevelData(current);
									gameCharacter.y=current.getX()*h;
									gameCharacter.x=current.getZ()*w;
								}
							}
							else
							{
								
								previous=previous.toPosition(solutionPathes.peek().getStateName().toString());
								current=current.toPosition(solutionPathes.pop().getStateName().toString());
								gameCharacter.y=current.getX()*h;
								gameCharacter.x=current.getZ()*w;
								firstPath=false;
							}
						}
						else
						{
							stop();
						}
						
						redraw();
					}
				});
			}
		};
		timer.scheduleAtFixedRate(timerTask, 0, 500);
	}
	
	public void stop()
	{
		if(displayingSolution)
		{
		  displayingSolution=false;
		  timer.cancel();
		  timerTask.cancel();
		}
	}

	public void moveLeft() {
		int width=getSize().x;
		int height=getSize().y;
		
		int w=width/mazeData[0].length;
		int h=height/mazeData.length;
		
		//gameCharacter.y=gameCharacter.y;
		//gameCharacter.x=(gameCharacter.x-1*w);
	    if(mazeAs3DimArray[currentPosition.getX()][currentPosition.getY()][currentPosition.getZ()-1]==0)
	    {
	    	gameCharacter.x=(currentPosition.getZ()-1)*w;
	    	currentPosition.setZ(currentPosition.getZ()-1);
	    }
		redraw();
		
	}

	public void moveRight() {
		int width=getSize().x;
		int height=getSize().y;
		
		int w=width/mazeData[0].length;
		int h=height/mazeData.length;
		
		//gameCharacter.y=gameCharacter.y;
		//gameCharacter.x=(gameCharacter.x+1*w);
		if(mazeAs3DimArray[currentPosition.getX()][currentPosition.getY()][currentPosition.getZ()+1]==0)
		{
			gameCharacter.x=(currentPosition.getZ()+1)*w;
			currentPosition.setZ(currentPosition.getZ()+1);
		}
		
		redraw();
		
	}

	public void moveDown() {
		int width=getSize().x;
		int height=getSize().y;
		
		int w=width/mazeData[0].length;
		int h=height/mazeData.length;
		
		//gameCharacter.y=(gameCharacter.y+1*h);
		//gameCharacter.x=gameCharacter.x;
		if(currentPosition.getX()<mazeAs3DimArray.length-1){
		if(mazeAs3DimArray[currentPosition.getX()+1][currentPosition.getY()][currentPosition.getZ()]==0)
		{
			gameCharacter.y=(currentPosition.getX()+1)*h;
			currentPosition.setX(currentPosition.getX()+1);
			
		}
		}
		
		redraw();
		
	}

	public void moveUp() {
		int width=getSize().x;
		int height=getSize().y;
		
		int w=width/mazeData[0].length;
		int h=height/mazeData.length;
		
		//gameCharacter.y=(gameCharacter.y-1*h);
		//gameCharacter.x=gameCharacter.x;
		if(currentPosition.getX()>0){
		if(mazeAs3DimArray[currentPosition.getX()-1][currentPosition.getY()][currentPosition.getZ()]==0)
		{
			gameCharacter.y=(currentPosition.getX()-1)*h;
			currentPosition.setX(currentPosition.getX()-1);
		}
		}
		
		redraw();
		
	}

	public void moveLevelUp() {
		if(currentPosition.getY()<mazeAs3DimArray[0].length-1){
		if(mazeAs3DimArray[currentPosition.getX()][currentPosition.getY()+1][currentPosition.getZ()]==0)
		{
			currentPosition.setY(currentPosition.getY()+1);
			setNewLevelData(currentPosition);
			setLevel(""+currentPosition.getY()+"");
		}
		}
		redraw();
	}

	public void moveLevelDown() {
		if(currentPosition.getY()>0){
		if(mazeAs3DimArray[currentPosition.getX()][currentPosition.getY()-1][currentPosition.getZ()]==0)
		{
			currentPosition.setY(currentPosition.getY()-1);
			setNewLevelData(currentPosition);
			setLevel(""+currentPosition.getY()+"");
		}
		}
		redraw();
	}
	
	
	public void setPerspective(String perspective)
	{
		this.perspective=perspective;
	}
	
	public boolean isPerspectiveY()
	{
		if(perspective.equals("y"))
			return true;
		else
			return false;
	}
	
	public void setLevel(String level)
	{
		this.level=level;
	}
	
	public String getLevel()
	{
		return level;
	}

	public void setExit(Position exit)
	{
		this.exit=exit;
	}
	
	public Position getExit()
	{
		return exit;
	}
	
	public Position getCurrentPosition()
	{
		return currentPosition;
	}
	
	public boolean cameToExit() {
		if(currentPosition.toString().equals(exit.toString()))
			return true;
		else
			return false;
	}

	public void stopGame() {
		
		gameStarted=false;
		
	}
}
