package View;

import java.util.ArrayList;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Spinner;

import Model.DataFromProperties;
import algorithms.mazeGenerators.Maze3d;
import algorithms.search.Solution;

public class MazeWindow extends BasicWindow implements View{

	String[]indexes={};
	String[]perspectives={"x","y","z"};
	String axis="";
	String mazeName="maze";
	String tempLevel="";
	String []lengths={};
	String []heights={};
	String []widths={};
	String []algorithms={"bfs","dfs"};
	String []views={"CLI","GUI"};
	MazeDisplay mazeDisplay;
	String choosenAlgorithm="";
	String setLevel="1";
	boolean mazeIsSolved=false;
	String choosenPerspective="";
	
	
	Menu menuBar, fileMenu, helpMenu;

	MenuItem fileMenuHeader, helpMenuHeader;

    MenuItem fileExitItem, filePropertiesItem, helpGetHelpItem;
    
    ArrayList<Thread> threads=new ArrayList<Thread>();

	
	public MazeWindow(String title, int width, int height) {
		super(title, width, height);
	}

	@Override
	void initWidgets() {
		
		GridLayout gridLayout = new GridLayout(3, false);
		shell.setLayout(gridLayout);
		
		/*Label nameLabel = new Label(shell, SWT.NONE);
		nameLabel.setLayoutData(new GridData(SWT.None, SWT.None, false, false, 1, 1));
		nameLabel.setText("Index: ");
		
		
		Combo setLevel = new Combo(shell, SWT.BORDER);
        setLevel.setLayoutData(new GridData(SWT.None, SWT.None, false, false, 1, 1));
		setLevel.setItems(indexes);*/
		
		
		
		
		//mazeDisplay.start();
		
		
		
		Label labelPerspective = new Label(shell, SWT.NONE);
		labelPerspective.setLayoutData(new GridData(SWT.None, SWT.None, false, false, 1, 1));
		labelPerspective.setText("Perspective: ");
		
		Combo setPerspective = new Combo(shell, SWT.BORDER);
		setPerspective.setLayoutData(new GridData(SWT.None, SWT.None, false, false, 1, 1));
		setPerspective.setItems(perspectives);
		
		
		
		mazeDisplay=new MazeDisplay(shell,SWT.BORDER);
		mazeDisplay.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 10));
		
		
		
		Label labelLength = new Label(shell, SWT.NONE);
		labelLength.setLayoutData(new GridData(SWT.None, SWT.None, false, false, 1, 1));
		labelLength.setText("Length: ");
		
		Combo setLength = new Combo(shell, SWT.BORDER);
		setLength.setLayoutData(new GridData(SWT.None, SWT.None, false, false, 1, 1));
		setLength.setItems(lengths);
		
		
		
		Label labelHeight= new Label(shell, SWT.NONE);
		labelHeight.setLayoutData(new GridData(SWT.None, SWT.None, false, false, 1, 1));
		labelHeight.setText("Height: ");
		
		Combo setHeight = new Combo(shell, SWT.BORDER);
		setHeight.setLayoutData(new GridData(SWT.None, SWT.None, false, false, 1, 1));
		setHeight.setItems(lengths);
		
		
		
		Label labelWidth = new Label(shell, SWT.NONE);
		labelWidth.setLayoutData(new GridData(SWT.None, SWT.None, false, false, 1, 1));
		labelWidth.setText("Width: ");
		
		Combo setWidth = new Combo(shell, SWT.BORDER);
		setWidth.setLayoutData(new GridData(SWT.None, SWT.None, false, false, 1, 1));
		setWidth.setItems(lengths);
		
		
		
		Label labelPosition = new Label(shell, SWT.NONE);
		labelPosition.setLayoutData(new GridData(SWT.None, SWT.None, false, false, 1, 1));
		labelPosition.setText("Position: ");
		
		Label labelDispalyPosition = new Label(shell, SWT.BORDER);
		labelDispalyPosition.setLayoutData(new GridData(SWT.None, SWT.None, false, false, 1, 1));
		labelDispalyPosition.setText("  {0,0,0}  ");
		
		
		
		Button btnGenerateMaze=new Button(shell, SWT.NONE);
		btnGenerateMaze.setText(" Generate maze ");
		btnGenerateMaze.setLayoutData(new GridData(SWT.None, SWT.None, false, false, 1, 1));
		
		Label labelEmpty = new Label(shell, SWT.NONE);
		labelEmpty.setLayoutData(new GridData(SWT.None, SWT.None, false, false, 1, 1));
		labelEmpty.setText("");
		
		
		
		Button btnSolveMaze=new Button(shell, SWT.NONE);
		btnSolveMaze.setText("    Solve maze    ");
		btnSolveMaze.setLayoutData(new GridData(SWT.None, SWT.None, false, false, 1, 1));
		
		Label labelEmpty1 = new Label(shell, SWT.NONE);
		labelEmpty1.setLayoutData(new GridData(SWT.None, SWT.None, false, false, 1, 1));
		labelEmpty1.setText("");
		
		
		
		
		Button btnGetHint=new Button(shell, SWT.NONE);
		btnGetHint.setText("       Get hint       ");
		btnGetHint.setLayoutData(new GridData(SWT.None, SWT.None, false, false, 1, 1));
		
		Label labelEmpty2 = new Label(shell, SWT.NONE);
		labelEmpty2.setLayoutData(new GridData(SWT.None, SWT.None, false, false, 1, 1));
		labelEmpty2.setText("");
		
		
		
		/*Label labelAlgorithm = new Label(shell, SWT.NONE);
		labelAlgorithm.setLayoutData(new GridData(SWT.None, SWT.None, false, false, 1, 1));
		labelAlgorithm.setText("Algorithm: ");
		
		Combo setAlgorithm = new Combo(shell, SWT.BORDER);
		setAlgorithm.setLayoutData(new GridData(SWT.None, SWT.None, false, false, 1, 1));
		setAlgorithm.setItems(algorithms);*/
		
		
		
		Button btnDisplaySolution=new Button(shell, SWT.NONE);
		btnDisplaySolution.setText("Display solution");
		btnDisplaySolution.setLayoutData(new GridData(SWT.None, SWT.None, false, false, 1, 1));
		
		Label labelEmpty3 = new Label(shell, SWT.NONE);
		labelEmpty3.setLayoutData(new GridData(SWT.None, SWT.None, false, false, 1, 1));
		labelEmpty3.setText("");
		
		
		
		Button btnStartNewGame=new Button(shell, SWT.NONE);
		btnStartNewGame.setText("Start new game ");
		btnStartNewGame.setLayoutData(new GridData(SWT.None, SWT.None, false, false, 1, 1));
		
		Label labelEmpty4 = new Label(shell, SWT.NONE);
		labelEmpty4.setLayoutData(new GridData(SWT.None, SWT.None, false, false, 1, 1));
		labelEmpty4.setText("");
		
		
	
		menuBar = new Menu(shell, SWT.BAR);
	    fileMenuHeader = new MenuItem(menuBar, SWT.CASCADE);
	    fileMenuHeader.setText("&File");

	    fileMenu = new Menu(shell, SWT.DROP_DOWN);
	    fileMenuHeader.setMenu(fileMenu);

	    filePropertiesItem = new MenuItem(fileMenu, SWT.PUSH);
	    filePropertiesItem.setText("&Properties");
	    
	    fileExitItem = new MenuItem(fileMenu, SWT.PUSH);
	    fileExitItem.setText("&Exit");

	    
	    shell.setMenuBar(menuBar);
	    
	    shell.addListener(SWT.Close, new Listener()
	    {
	    	@Override
	        public void handleEvent(Event event)
	        {
	            int style = SWT.APPLICATION_MODAL | SWT.YES | SWT.NO;
	            MessageBox messageBox = new MessageBox(shell, style);
	            messageBox.setText("Information");
	            messageBox.setMessage("Are you sure you want to quit?");
	            if(messageBox.open() == SWT.YES)
	            {
	            	mazeDisplay.stop();
	            	String command="exit";
	            	setChanged();
	            	notifyObservers(command);
	            	stopThreads();
	            	event.doit=true;
	            }
	            else
	            {
	            	event.doit=false;
	            }
	            
	        }
	    });
	    
	    
	    fileExitItem.addSelectionListener(new SelectionAdapter(){
	    	public void widgetSelected(SelectionEvent e) {
	    		String command="exit";
	    		setChanged();
	    		notifyObservers(command);
	    		shell.close();
	    	    display.dispose();
		   }
	    });
	    
	    filePropertiesItem.addSelectionListener(new SelectionAdapter(){
	    	public void widgetSelected(SelectionEvent e) {
	    		Thread thread=new Thread(new Runnable(){

	    			@Override
	    			public void run() {
	    				Display display1 = new Display();
	    			    Shell shell1 = new Shell(display1);

	    			    
	
	    			    //choosenAlgorithm
	    			    
	    			    GridLayout gridLayout = new GridLayout(2, false);
	    				shell1.setLayout(gridLayout);
	    				
	    				Label labelAlgorithms = new Label(shell1, SWT.NONE);
	    				labelAlgorithms.setLayoutData(new GridData(SWT.None, SWT.None, false, false, 1, 1));
	    				labelAlgorithms.setText("Algorithm: ");
	    				
	    				
	    				Combo setAlgorithm = new Combo(shell1, SWT.BORDER);
	    		        setAlgorithm.setLayoutData(new GridData(SWT.None, SWT.None, false, false, 1, 1));
	    				setAlgorithm.setItems(algorithms);
	    				
	    				
	    				
	    				Label labelView = new Label(shell1, SWT.NONE);
	    				labelView.setLayoutData(new GridData(SWT.None, SWT.None, false, false, 1, 1));
	    				labelView.setText("View: ");
	    			
	    				Combo setView = new Combo(shell1, SWT.BORDER);
	    				setView.setLayoutData(new GridData(SWT.None, SWT.None, false, false, 1, 1));
	    				setView.setItems(views);
	    				
	    				
	    				
	    				Label labelMazeSize = new Label(shell1, SWT.NONE);
	    				labelMazeSize.setLayoutData(new GridData(SWT.None, SWT.None, false, false, 1, 1));
	    				labelMazeSize.setText("Max size: ");
	    			
	    				//Combo setMazeSize = new Combo(shell1, SWT.BORDER);
	    				//setMazeSize.setLayoutData(new GridData(SWT.None, SWT.None, false, false, 1, 1));
	    				//setMazeSize.setItems(views);
	    				
	    				
	    				Spinner setMaxSize = new Spinner(shell1, SWT.BORDER);
	    				setMaxSize.setMinimum(0);
	    				setMaxSize.setMaximum(100);
	    			    //spinner.setSelection(500);
	    				setMaxSize.setIncrement(1);
	    			    //spinner.setPageIncrement(100);
	    				setMaxSize.pack();
	    				
	    				
	    				//choosenAlgorithm=(String)setAlgorithm.getText();
	    				
	    				Button btnExit=new Button(shell1, SWT.NONE);
	    				btnExit.setText("Close");
	    				btnExit.setLayoutData(new GridData(SWT.None, SWT.None, false, false, 1, 1));
	    				
	    				Button btnSave=new Button(shell1, SWT.NONE);
	    				btnSave.setText("Save ");
	    				btnSave.setLayoutData(new GridData(SWT.None, SWT.None, false, false, 1, 1));
	    				
	    				
	    				
	    			 
	    			    btnExit.addSelectionListener(new SelectionListener() {
	    					
	    					@Override
	    					public void widgetSelected(SelectionEvent arg0) {
	    						//choosenAlgorithm=(String)setAlgorithm.getText();
	    						//System.out.println(choosenAlgorithm);
	    						shell1.close();
	    						display1.close();
	    					}
	    					
	    					@Override
	    					public void widgetDefaultSelected(SelectionEvent arg0) {}
	    				});
	    			    
	    			    
	    			    
	    			    btnSave.addSelectionListener(new SelectionListener() {
	    					
	    					@Override
	    					public void widgetSelected(SelectionEvent arg0) {
	    						
	    						String command="saveProperties"+" "+(String)setAlgorithm.getText()+" "+(String)setMaxSize.getText()+" "+(String)setView.getText();
	    						//System.out.println((String)setAlgorithm.getText());
	    						//System.out.println();
	    						setChanged();
	    						notifyObservers(command);
	    						shell1.close();
	    						display1.close();
	    					}
	    					
	    					@Override
	    					public void widgetDefaultSelected(SelectionEvent arg0) {}
	    				});
	    			    
	    			    
	    			    shell1.setSize(150,200);
	    			    shell1.open();
	    			    
	    			    while (!shell1.isDisposed()) {
	    			        if (!display1.readAndDispatch())
	    			        	display1.sleep();
	    			      }
	    			    display1.dispose();
	    			    //display1.dispose();
	    			}
	    		});
	    		thread.start();
	    		threads.add(thread);
		   }
	    });
		
		
		//setLevel.setEnabled(false);
		//setPerspective.setEnabled(false);
		//btnSolveMaze.setEnabled(false);
		//setAlgorithm.setEnabled(false);
		
		/*setLevel.addSelectionListener(new SelectionAdapter() {
		      public void widgetSelected(SelectionEvent e) {
		    	  String command="displayCrossSection"+" "+(String)setPerspective.getText()+" "+(String)setLevel.getText()+" "+mazeName;
		    	  mazeDisplay.setPerspective((String)setPerspective.getText());
		    	  setChanged();
		    	  notifyObservers(command);
		      }
		});*/
		
		
		
		setPerspective.addSelectionListener(new SelectionAdapter() {
		      public void widgetSelected(SelectionEvent e) {
		    	  String command="displayCrossSection"+" "+setPerspective.getText()+" "+(String)mazeDisplay.getLevel()+" "+mazeName;
		    	  mazeDisplay.setPerspective((String)setPerspective.getText());
		    	  choosenPerspective=(String)setPerspective.getText();
		    	  setChanged();
		    	  notifyObservers(command);
		      }
		});
		

		
		btnGenerateMaze.addSelectionListener(new SelectionListener() {
			
			@Override
			public void widgetSelected(SelectionEvent arg0) {
				String command="generate3dMaze"+" "+mazeName+" "+(String)setLength.getText()+" "+(String)setHeight.getText()+" "+(String)setWidth.getText();
		    	setChanged();
		    	notifyObservers(command);
		    	
		    	//setLevel.setEnabled(true);
				setPerspective.setEnabled(true);
				btnSolveMaze.setEnabled(true);
				//setAlgorithm.setEnabled(true);
			}
			
			@Override
			public void widgetDefaultSelected(SelectionEvent arg0) {}
		});
		
		
		btnSolveMaze.addSelectionListener(new SelectionListener() {
			
			@Override
			public void widgetSelected(SelectionEvent arg0) {
			if(mazeDisplay.ifGameStarted())
			{
				String command="solve"+" "+mazeName+" "+(String)choosenAlgorithm;
		    	setChanged();
		    	notifyObservers(command);
			}
			else
			{
				displayMessage("You have to generate maze first");
			}
			}
			
			@Override
			public void widgetDefaultSelected(SelectionEvent arg0) {}
		});
		
		
		btnDisplaySolution.addSelectionListener(new SelectionListener() {
			
			@Override
			public void widgetSelected(SelectionEvent arg0) {
				if(mazeDisplay.ifGameStarted())
				{
				  if(choosenPerspective.equals("")==false)
				  {
					  String command="displaySolution"+" "+mazeName;
					  btnDisplaySolution.setEnabled(false);
					  setChanged();
					  notifyObservers(command);
				  }
				  else
				  {
					  displayMessage("You have to choose perspective first");
				  }
				}
				else
				{
					displayMessage("You have to generate maze first");
				}
			}
			
			@Override
			public void widgetDefaultSelected(SelectionEvent arg0) {}
		});
		
		
		btnGetHint.addSelectionListener(new SelectionListener() {
			
			@Override
			public void widgetSelected(SelectionEvent arg0) {
				displayMessage("Exit from the maze is: "+mazeDisplay.getExit().toString());
			}
			
			@Override
			public void widgetDefaultSelected(SelectionEvent arg0) {}
		});
		
		
		btnStartNewGame.addSelectionListener(new SelectionListener() {
			
			@Override
			public void widgetSelected(SelectionEvent arg0) {
				int mazeData[][]=new int[1][1];
				int maze[][][]=new int[1][1][1];
				mazeData[0][0]=0;
				mazeDisplay.setMazeData(mazeData);
				mazeDisplay.setMaze(maze);
				mazeDisplay.stopGame();
				mazeDisplay.stop();
				btnDisplaySolution.setEnabled(true);
				
			}
			
			@Override
			public void widgetDefaultSelected(SelectionEvent arg0) {}
		});
		
		
		mazeDisplay.addKeyListener(new KeyAdapter(){
			
			public void keyPressed(KeyEvent event) 
			{
				
		        switch (event.keyCode) {
		        case SWT.ARROW_LEFT:{
		        	 if(mazeDisplay.isPerspectiveY())
		        		 mazeDisplay.moveLeft();
		        	 else
		        	 {
		        		 displayMessage("You can move character only in y perspective");
		        	 }
		        	 break;
		        }
		        case SWT.ARROW_RIGHT:{
		        	 if(mazeDisplay.isPerspectiveY())
		        		 mazeDisplay.moveRight();
		        	 else
		        	 {
		        		 displayMessage("You can move character only in y perspective");
		        	 }
		        	 break;
		        }
		        case SWT.ARROW_DOWN:{
		        	 if(mazeDisplay.isPerspectiveY())
		        		 mazeDisplay.moveDown();
		        	 else
		        	 {
		        		 displayMessage("You can move character only in y perspective");
		        	 }
		        	 break;
		        }
			    case SWT.ARROW_UP:{
			    	 if(mazeDisplay.isPerspectiveY())
		        		 mazeDisplay.moveUp();
		        	 else
		        	 {
		        		 displayMessage("You can move character only in y perspective");
		        	 }
		        	 break;
			    }
			    case SWT.PAGE_DOWN:{
			    	 if(mazeDisplay.isPerspectiveY())
		        		 mazeDisplay.moveLevelDown();
		        	 else
		        	 {
		        		 displayMessage("You can move character only in y perspective");
		        	 }
		        	 break;
			    }
			    case SWT.PAGE_UP:{
			    	 if(mazeDisplay.isPerspectiveY())
		        		 mazeDisplay.moveLevelUp();
		        	 else
		        	 {
		        		 displayMessage("You can move character only in y perspective");
		        	 }
		        	 break;
			    }
		        }
		        //System.out.println(mazeDisplay.getExit().toString());
		        if(mazeDisplay.cameToExit())
		        {
		        	
		        	displayWinnerMessage();
		        }
		        labelDispalyPosition.setText(mazeDisplay.getCurrentPosition().toString());
		     }
		});
	}
	
	@Override
	public void displayCrossSection(Maze3d maze, String axis, int index) {
        int mazeAsArray[][][]=maze.getMazeAs3DimArray();
		int mazeData[][]=null;
		if(axis.equals("x")==true){
			mazeData=new int[maze.getHeight()][maze.getWidth()];
			for(int y=0;y<maze.getHeight();y++)
			{
				for(int z=0;z<maze.getWidth();z++)
				{
					mazeData[y][z]=mazeAsArray[index][y][z];
				}
			}
		}
			
		if(axis.equals("y")==true){
			mazeData=new int[maze.getLength()][maze.getWidth()];
			for(int x=0;x<maze.getLength();x++)
			{
				for(int z=0;z<maze.getWidth();z++)
				{
					mazeData[x][z]=mazeAsArray[x][index][z];
				}
			}
		}
			
		if(axis.equals("z")==true){
			mazeData=new int[maze.getLength()][maze.getHeight()];
			for(int x=0;x<maze.getLength();x++)
			{
				for(int y=0;y<maze.getHeight();y++)
				{
					mazeData[x][y]=mazeAsArray[x][y][index];
				}
			}
		}
		
		mazeDisplay.setMazeData(mazeData);
		mazeDisplay.setMaze(mazeAsArray);
		mazeDisplay.setExit(maze.getGoalPosition());
	}
	
	@Override
	public void start()
	{
		this.run();
	}

	@Override
	public void displayMessage(String message) {
		
		Thread thread=new Thread(new Runnable(){

			@Override
			public void run() {
				Display display1 = new Display();
			    Shell shell1 = new Shell(display1);

			    int style = SWT.ICON_INFORMATION |SWT.OK | SWT.CANCEL;
			    
			    MessageBox messageBox = new MessageBox(shell1, style);
			    messageBox.setMessage(message);
			    int rc = messageBox.open();

			    switch (rc) {
			    case SWT.OK:
			      break;
			    case SWT.CANCEL:
			      break;
			    case SWT.YES:
			      break;
			    case SWT.NO:
			      break;
			    case SWT.RETRY:
			      break;
			    case SWT.ABORT:
			      break;
			    case SWT.IGNORE:
			      break;
			    }
			    
			    display1.dispose();
			}
		});
		thread.start();
		threads.add(thread);
		
		
		String search1  = "Maze";
		String search2 =  "is ready";
		if ((message.toLowerCase().indexOf(search1.toLowerCase()) != -1 )&&(message.toLowerCase().indexOf(search2.toLowerCase()) != -1 )) {
			mazeIsSolved=true;
			mazeDisplay.startGame();
			mazeDisplay.setPerspective("y");
			//System.out.println("sdfsdfsdfsdfsdf");
			String command="displayCrossSection"+" "+"y"+" "+"1"+" "+mazeName;
			setChanged();
			notifyObservers(command);
		};
	}

	@Override
	public void displayMaze(Maze3d maze) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void displayFilesList(String[] filesList) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void displaySolution(Solution solution) {
		mazeDisplay.setSolution(solution);
		mazeDisplay.start();
	}

	@Override
	public void setProperties(DataFromProperties dfp) {
		
		int size=Integer.parseInt(dfp.getMaxMazeSize());
		lengths=new String[size];
		heights=new String[size];
		widths=new String[size];
		indexes=new String[size];
		
		for(int i=0;i<size;i++)
		{
			
			lengths[i]=""+(i+3)+"";
			heights[i]=""+(i+3)+"";
			widths[i]=""+(i+3)+"";
			indexes[i]=""+(i+3)+"";
		}
		
		choosenAlgorithm=dfp.getDefaultAlgorithm();
	}
	
	public void displayWinnerMessage()
	{
		Thread thread=new Thread(new Runnable(){
		

		@Override
		public void run() {
			final Display display1 = new Display();
		    final Shell shell1 = new Shell(display1);
		    shell1.setText("!!!WINNER!!!");
		    shell1.setLayout(new FillLayout());

		    Canvas canvas = new Canvas(shell1, SWT.NONE);

		    //int height;
		    //int width;
		    
		    canvas.addPaintListener(new PaintListener() {
		      public void paintControl(PaintEvent e) {
		        
		    	Image image = new Image(display1, "winner.jpg");
		        e.gc.drawImage(image, 0, 0);
		        image.dispose();
		        //System.out.println(image.getBounds().width);
		       // System.out.println(image.getBounds().height);
		        
		      }
		    });
		    
		    shell1.setSize(600,310);
		    shell1.open();
		    while (!shell1.isDisposed()) {
		      if (!display1.readAndDispatch()) {
		        display1.sleep();
		      }
		    }
		    display1.dispose();
		}
		
	    });
		thread.start();
		threads.add(thread);
	}
	
	public void stopThreads()
	{
		for(int i=0;i<threads.size();i++)
		{
			threads.get(i).interrupt();
		}
	}
}
