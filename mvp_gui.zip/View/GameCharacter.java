package View;

import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.graphics.Pattern;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Display;

public class GameCharacter {
	int x;
	int y;
	int z;
	Image image;
	
	public GameCharacter(int x,int y,int z){
		this.x=x;
		this.y=y;
		this.z=z;
		
		//Display display=new Display();
		//image = new Image(new Display(), "mario.png");
	}
	
	public void paint(PaintEvent e,int w,int h)
	{
		//e.gc.setBackground(new Color(null,255,0,0));
		image = new Image(e.display, "fractal1.jpg");
		e.gc.setBackgroundPattern(new Pattern(e.display,image));
		e.gc.fillOval(x, y, w, h);
		
		
		
	     //data.horizontalAlignment = SWT.FILL;
	    
		
		
		
		/* image = new Image(e.display, "mario.png");
		 ImageData data = image.getImageData();
		 int srcX = data.width;
	     int srcY = data.height;
	     int srcWidth = data.width;
	     int srcHeight = data.height;
	     int destWidth = w;
	     int destHeight = h;*/

	    // e.gc.drawImage(image, srcX, srcY, srcWidth, srcHeight, destWidth, destHeight, destWidth, destHeight);
		//e.gc.drawImage(arg0, arg1, arg2);
	}
}
