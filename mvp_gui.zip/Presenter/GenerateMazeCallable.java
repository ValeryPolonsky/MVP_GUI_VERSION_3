package Presenter;

import java.util.concurrent.Callable;

import Model.Model;
import algorithms.mazeGenerators.Maze3d;

public class GenerateMazeCallable implements Callable<Maze3d> {

	private Model model;
	private String mazeName;
	private int length;
	private int height;
	private int width;
	
	public GenerateMazeCallable(Model model,String mazeName,int length,int height,int width)
	{
		this.model=model;
		this.mazeName=mazeName;
		this.length=length;
		this.height=height;
		this.width=width;
	}
	
	@Override
	public Maze3d call() throws Exception {
		return model.generateMaze(mazeName, length, height, width);
	}
}
