package Presenter;

import Model.Model;
import View.View;

public class SaveMazesAndSolutionsCommand {
	Model model;
	View view;
	
	public SaveMazesAndSolutionsCommand(Model model,View view)
	{
		this.model=model;
		this.view=view;
		saveMazesAndSolutions();
	}
	
	private void saveMazesAndSolutions()
	{
		model.saveMazesAndSolutions();
	}

}
