package Presenter;

import Model.Model;
import View.View;
import algorithms.search.Solution;

public class DisplaySolutionCommand implements Command {

	Model model;
	View view;
	
	public DisplaySolutionCommand(Model model,View view)
	{
		this.model=model;
		this.view=view;
	}
	
	@Override
	public void doCommand(String[] args) {
		if(args.length!=1)
		{
			view.displayMessage("\n!!!Wrong number of arguments!!!\n\n");
			return;
		}
		
		Solution solution=model.getSolution(args[0]);
		if(solution==null)
		{
			view.displayMessage("\n!!!There is no solution for "+args[0]+" maze!!!\n\n");
			return;
		}
		
		String message="The solution of maze "+args[0]+" is: ";
		view.displayMessage(message);
		view.displaySolution(solution);
	}
}
