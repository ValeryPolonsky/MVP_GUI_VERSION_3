package Presenter;

import Model.Model;
import View.View;
import algorithms.mazeGenerators.Maze3d;

public class DisplayMazeCommand implements Command {

	private Model model;
	private View view;
	
	public DisplayMazeCommand(Model model,View view){
		this.view=view;
		this.model=model;
	}
	
	@Override
	public void doCommand(String[] args) {
		
		if(args.length!=1)
		{
			view.displayMessage("\n!!!Wrong number of arguments!!!\n\n");
			return;
		}
		
		Maze3d maze=model.getMaze(args[0]);
		if(maze==null)
		{
			view.displayMessage("\n!!!The maze "+args[0]+" doesn't exist!!!\n\n");
			return;
		}
		view.displayMaze(maze);
	}
}
