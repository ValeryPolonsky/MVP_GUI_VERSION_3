package Presenter;

import Model.Model;
import View.View;

public class ExitCommand implements Command {

	Presenter presenter;
	Model model;
	View view;
	
	public ExitCommand(Presenter presenter,Model model,View view)
	{
		this.presenter=presenter;
		this.model=model;
		this.view=view;
	}
	
	@Override
	public void doCommand(String[] args) {
		new SaveMazesAndSolutionsCommand(model,view);
		presenter.shutdownExecutor();
	}

}
