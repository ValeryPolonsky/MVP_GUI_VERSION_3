package Presenter;

import Model.Model;
import View.View;

public class SavePropertiesCommand implements Command {
	Model model;
	View view;
	
	public SavePropertiesCommand(Model model, View view)
	{
		this.model=model;
		this.view=view;
	}

	@Override
	public void doCommand(String[] args) {
		model.saveProperties(args[0],args[1],args[2]);
		view.displayMessage("Changes will take place after reload of the program");
	}
	
	

}
