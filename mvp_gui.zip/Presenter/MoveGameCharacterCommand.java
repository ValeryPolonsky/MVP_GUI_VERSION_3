package Presenter;

import View.View;

public class MoveGameCharacterCommand implements Command {

	View view;
	
	public MoveGameCharacterCommand(View view)
	{
		this.view=view;
	}
	
	@Override
	public void doCommand(String[] args) {
		if(args[0].equals("arrow_left"))
		{
			//view.moveGameCharacter
		}

	}

}
