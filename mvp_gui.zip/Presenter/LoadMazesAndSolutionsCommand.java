package Presenter;

import Model.Model;
import View.View;

public class LoadMazesAndSolutionsCommand {
	
	Model model;
	View view;
	
	public LoadMazesAndSolutionsCommand(Model model,View view)
	{
		this.model=model;
		this.view=view;
		loadMazesAndSolutions();
	}
	
	private void loadMazesAndSolutions()
	{
		model.loadMazesAndSolutions();
	}
}
