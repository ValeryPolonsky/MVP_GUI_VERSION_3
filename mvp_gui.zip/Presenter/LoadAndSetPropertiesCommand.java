package Presenter;

import Model.DataFromProperties;
import Model.Model;
import View.View;

public class LoadAndSetPropertiesCommand {
	Model model;
	View view;
	
	public LoadAndSetPropertiesCommand(Model model,View view)
	{
		this.model=model;
		this.view=view;
		loadAndSetProperties();
	}
	
	
	public void loadAndSetProperties()
	{
		DataFromProperties dfp=model.loadProperties();
		view.setProperties(dfp);
	}
}
