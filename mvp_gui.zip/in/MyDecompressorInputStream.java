package in;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.UnsupportedEncodingException;


public class MyDecompressorInputStream extends InputStream{

	InputStream in;
	int size ;
	
	public int getSize() {
		return size;
	}

	public void close()throws IOException{
		in.close();
	}
	
	public MyDecompressorInputStream(InputStream input) throws IOException{
		this.in = input;
		
	}

	public MyDecompressorInputStream() throws FileNotFoundException, IOException {
		in = new ObjectInputStream(new FileInputStream("out.txt"));
	}
	
	public int read(int b) throws IOException {
		in.read();
		return -1;
	}
	@Override
	public int read(byte[] b) throws IOException {
		byte[]temp=new byte[b.length];
		in.read(temp);
		byte[]temp1=decompress(temp);
		for(int i=0;i<temp1.length;i++)
		{
			b[i]=temp1[i];
		}
		return -1;
	}

	@Override
	public int read() throws IOException {
		return 0;
	}
	
	private byte[]decompress(byte[]data) throws UnsupportedEncodingException
	{
		String str=";";
		byte[]separator=str.getBytes("UTF-8");
		int k=0;
		int endIndex=0;
		int startIndex=0;
		boolean zeroTurn=true;
		boolean changed=false;
		byte[]temp1=new byte[data.length*10];
		for(int i=0;i<5;i++)
		{
			endIndex=indexOf(data,separator,startIndex);
			startIndex=endIndex+1;
		}
		
		for(int i=0;i<data.length;i++)
		{
			if(i<=endIndex)
			{
				temp1[k]=data[i];
				k++;
			}
			else
			{
				if(zeroTurn==true&&changed==false)
				{
					if(data[i]!=0)
					{
						for(int j=0;j<(data[i]& 0xff);j++)
						{
							temp1[k]=0;
							k++;
						}
					}
					zeroTurn=false;
					changed=true;
				}
				if(zeroTurn==false&&changed==false)
				{
					if(data[i]!=0)
					{
						for(int j=0;j<(data[i]& 0xff);j++)
						{
							temp1[k]=1;
							k++;
						}
					}
					zeroTurn=true;
					changed=true;
				}
				changed=false;
			}
		}
		byte[]temp2=new byte[k];
		for(int i=0;i<k;i++)
		{
			temp2[i]=temp1[i];
		}
		
		return temp2;
	}
	
	
	private int indexOf(byte[] outerArray, byte[] smallerArray, int startIndex) 
	{
	    for(int i = startIndex; i < outerArray.length - smallerArray.length+1; ++i) 
	    {
	        boolean found = true;
	        for(int j = 0; j < smallerArray.length; ++j) 
	        {
	           if (outerArray[i+j] != smallerArray[j]) 
	           {
	               found = false;
	               break;
	           }
	        }
	        if (found) return i;
	    }
	    return -1;  
	}  
}
