package io;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

import java.io.UnsupportedEncodingException;

public class MyCompressorOutputStream extends OutputStream {

	private OutputStream out;
	
	public MyCompressorOutputStream(OutputStream output)
	{
		this.out=output;
	}
	
	public MyCompressorOutputStream() throws FileNotFoundException, IOException
	{
		this.out=new ObjectOutputStream(new FileOutputStream("out.txt"));
	}
	
	
	@Override
	public void write(int b) throws IOException {
		out.write(b);
	}
	

	public void write(byte[]data) throws IOException {
		
		byte[]temp=compress(data);
		for(int i=0;i<temp.length;i++)
		{
			out.write(temp[i]);
		}
	}
	
	private byte[]compress(byte[]data) throws UnsupportedEncodingException
	{
		String str=";";
		byte[]separator=str.getBytes("UTF-8");
		int zeroCount=0;
		int oneCount=0;
		int k=0;
		int endIndex=0;
		int startIndex=0;
		boolean zeroTurn=true;
		boolean changed=false;
		byte[]temp1=new byte[data.length];
		for(int i=0;i<5;i++)
		{
			endIndex=indexOf(data,separator,startIndex);
			startIndex=endIndex+1;
		}
		
		for(int i=0;i<data.length;i++)
		{
			if(i<=endIndex)
			{
				temp1[k]=data[i];
				k++;
			}
			else
			{
				if(data[i]==0&&zeroTurn==true&&changed==false)
				{
					if(zeroCount<255)
					{
						zeroCount++;
					}
					else
					{
						temp1[k]=(byte)zeroCount;
						temp1[k+1]=0;
						k+=2;
						zeroCount=1;
					}
					changed=true;
				}
				if(data[i]==1&&zeroTurn==true&&changed==false)
				{
					temp1[k]=(byte)zeroCount;
					zeroCount=0;
					oneCount++;
					changed=true;
					zeroTurn=false;
					k++;
				}
				if(data[i]==1&&zeroTurn==false&&changed==false)
				{
					if(oneCount<255)
					{
						oneCount++;
					}
					else
					{
						temp1[k]=(byte)oneCount;
						temp1[k+1]=0;
						k+=2;
						oneCount=1;
					}
					changed=true;
				}
				if(data[i]==0&&zeroTurn==false&&changed==false)
				{
					temp1[k]=(byte)oneCount;
					oneCount=0;
					zeroCount++;
					changed=true;
					zeroTurn=true;
					k++;
				}
				changed=false;
			}
		}
		if(oneCount!=0)
			temp1[k]=(byte)oneCount;
		
		byte[]temp2=new byte[k+1];
		for(int i=0;i<k+1;i++)
		{
			temp2[i]=temp1[i];
		}
		
		return temp2;
	}
	
	private int indexOf(byte[] outerArray, byte[] smallerArray, int startIndex) 
	{
	    for(int i = startIndex; i < outerArray.length - smallerArray.length+1; ++i) 
	    {
	        boolean found = true;
	        for(int j = 0; j < smallerArray.length; ++j) 
	        {
	           if (outerArray[i+j] != smallerArray[j]) 
	           {
	               found = false;
	               break;
	           }
	        }
	        if (found) return i;
	    }
	    return -1;  
	}  
	

}
