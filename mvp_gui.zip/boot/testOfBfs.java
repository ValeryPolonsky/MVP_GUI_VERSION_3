package boot;

import algorithms.search.BFSTest;
import algorithms.search.DFSTest;

public class testOfBfs {

	public static void main(String[] args) {
		//BFSTest test=new BFSTest();
		//test.test();
		//DFSTest test=new DFSTest();
		//test.test();
	}

}
