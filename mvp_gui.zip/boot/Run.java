package boot;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.io.PrintWriter;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import Model.MyModel;
import Presenter.Presenter;
import View.BasicWindow;
import View.MazeWindow;
import View.MyView;


public class Run {

	public static void main(String[] args) {
		
		/*MyModel model = new MyModel();		
	    MazeWindow view = new MazeWindow("Game",500,500);
		
		Presenter presenter = new Presenter(model, view);
		view.addObserver(presenter);
	    model.addObserver(presenter);
		
		view.start();	*/
		
		MyModel model=new MyModel();
		String viewSetup=model.loadProperties().getViewSetup();
		if(viewSetup.equals("CLI"))
		{
			BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
			PrintWriter writer = new PrintWriter(System.out);
			MyView view = new MyView(reader, writer);
			
			Presenter presenter = new Presenter(model, view);
			view.addObserver(presenter);
			model.addObserver(presenter);
			
			view.start();	
		}
		if(viewSetup.equals("GUI"))
		{	
		    MazeWindow view = new MazeWindow("Game",500,500);
			
			Presenter presenter = new Presenter(model, view);
			view.addObserver(presenter);
		    model.addObserver(presenter);
			
			view.start();
		}
		
		
		
			
		
		
		
		/* final Display display = new Display();
		    final Shell shell = new Shell(display);
		    shell.setText("Canvas Example");
		    shell.setLayout(new FillLayout());

		    Canvas canvas = new Canvas(shell, SWT.NONE);

		    canvas.addPaintListener(new PaintListener() {
		      public void paintControl(PaintEvent e) {
		        Image image = new Image(display, "mario.png");

		        ImageData data = image.getImageData();
		        
		        data.setPixel(5,5,5);
		        
		        Image anotherImage = new Image(display, data);
		        e.gc.drawImage(anotherImage, 10, 10);
		        image.dispose();
		      }
		    });

		    shell.open();
		    while (!shell.isDisposed()) {
		      if (!display.readAndDispatch()) {
		        display.sleep();
		      }
		    }
		    display.dispose();*/
		
		  }
		
	
}
