package boot;
 
 
import java.io.File;
 
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
 
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import Model.SaveAndLoadProperties;
 
 
public class XMLWriterDOM {
 
    public static void main(String[] args) {
    	
    	
    	SaveAndLoadProperties salp=new SaveAndLoadProperties();
    	//salp.saveGameProperties();
    	salp.loadGameProperties();
    	
    	
    	
        /*DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder;
        try {
            dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.newDocument();
            //add elements to Document
            Element rootElement = doc.createElementNS("gameData","gameData");
            //append root element to document
            doc.appendChild(rootElement);
 
            //append first child element to root element
            rootElement.appendChild(getGameData(doc, "1", "Pankaj", "29", "Java Developer"));
 
            //append second child
            //rootElement.appendChild(getEmployee(doc, "2", "Lisa", "35", "Manager", "Female"));
 
            //for output to file, console
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            //for pretty print
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            DOMSource source = new DOMSource(doc);
 
            //write to console or file
            StreamResult console = new StreamResult(System.out);
            StreamResult file = new StreamResult(new File("properties.xml"));
 
            //write data
            transformer.transform(source, console);
            transformer.transform(source, file);
            System.out.println("DONE");
 
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
 
 
    private static Node getGameData(Document doc, String id, String viewSetup, String maxMazeSize, String defaultAlgorithm)
    {
        Element element = doc.createElement("Element");
 
        //set id attribute
        element.setAttribute("id", id);
 
        //create name element
        element.appendChild(getEmployeeElements(doc, element, "viewSetup", viewSetup));
 
        //create age element
        element.appendChild(getEmployeeElements(doc, element, "maxMazeSize", maxMazeSize));
 
        //create role element
        element.appendChild(getEmployeeElements(doc, element, "defaultAlgorithm", defaultAlgorithm));
 
        //create gender element
        //element.appendChild(getEmployeeElements(doc, element, "gender", gender));
 
        return element;
    }
 
 
    //utility method to create text node
    private static Node getEmployeeElements(Document doc, Element element, String name, String value) {
        Element node = doc.createElement(name);
        node.appendChild(doc.createTextNode(value));
        return node;
    }*/
 
}
}